<?php

namespace NB\MainBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NBMainBundle extends Bundle
{
}
