<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 3/5/17
 * Time: 3:37 AM
 */

namespace NB\MainBundle\Controller;


use NB\MainBundle\Entity\Reservation;
use NB\MainBundle\Entity\Ticket;
use NB\MainBundle\Entity\Transaction;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Unirest;
class MainController extends Controller {

    public function indexAction(){

        $em = $this->getDoctrine()->getManager();
        $villes = $em->getRepository('NBMainBundle:Ville')->ListeVilles();
        $compagnie = $em->getRepository('NBMainBundle:Compagnie')->findAll();


        return $this->render('NBMainBundle::index.html.twig', [
            'ville' => $villes,
            'compagnie' => $compagnie
        ]);
    }

    public function listingAction(Request $request){

        if($request->getMethod() == 'GET'){
            $depart =  $this->get('doctrine.orm.entity_manager')->getRepository('NBMainBundle:Ville') ->findByName($request->get('from'));
            $arrivee = $this->get('doctrine.orm.entity_manager')->getRepository('NBMainBundle:Ville') ->findByName($request->get('to'));
        }
        $admin_link = $this->getParameter('admin_link');

        $search =  $this->get('doctrine.orm.entity_manager')
            ->getRepository('NBMainBundle:Voyages')
            ->findByAxes($depart->getId(), $arrivee->getId());

        return $this->render('NBMainBundle::listing.html.twig', [
            'departure' => $depart,
            'arrival' => $arrivee,
            'search' => $search,
            'admin_link' => $admin_link,
            'dateJ' => $request->get('dateJ')
        ]);
    }

    public function infosAction($travel_id, $dateJ, Request $request){

        $user = $this->getUser();
        $em = $this->getDoctrine()->getManager();
        $count =  $this->get('doctrine.orm.entity_manager')->getRepository('NBMainBundle:Reservation') ->getTotalRows()->getId() + 1;

        $search =  $this->get('doctrine.orm.entity_manager')
            ->getRepository('NBMainBundle:Voyages')
            ->find($travel_id);
        $admin_link = $this->getParameter('admin_link');
        $reservation = new Reservation();
        $ticket = new Ticket();


        if($request->getMethod() == 'POST'){
            $nom = $request->get('nom');
            $prenom = $request->get('prenom');
            $email = $request->get('email');
            $age = $request->get('age');
            $sexe = $request->get('sexe');
            $telephone = $request->get('telephone');


            $reservation->setDoj($dateJ);
            $reservation->setVoyages($search);
            $reservation->setChannel('web');
            if ($this->isGranted('ROLE_USER') == true)
                $reservation->setChannelId($user->getId());
            else
                $reservation->setChannelId('user');
            $reservation->setSeats('1');
            $reservation->setConfirmed(false);
            $reservation->setDateAdd(new \datetime);
            $reservation->setDateUpd(new \datetime);
            $em->persist($reservation);
            $ticketNo =
                (($this->isGranted('ROLE_USER') == true)?$user->getId():$reservation->getId() ). ( ( $search->getAxes()->isTypeBus() == 0)?'O':'C').
                strtoupper(substr($search->getAxes()->getSource()->getNom(), 0, 1).substr($search->getAxes()->getDestination()->getNom(), 0, 2)).
                $count;

            $ticket->setNom($nom." ".$prenom);
            $ticket->setAge($age);
            $ticket->setGender($sexe);
            $ticket->setTelephone($telephone);
            $ticket->setEmail($email);
            $ticket->setTicketNo($ticketNo);
            $reservation->setTickets($ticket);
            $em->persist($reservation);
            $em->flush();


            return $this->redirect($this->generateUrl('nb_main_payment', ['id' => $reservation->getId()]));
        }


        return $this->render('NBMainBundle::custInfo.html.twig', [
            'search' => $search,
            'admin_link' => $admin_link,
            'dateJ' => $dateJ
        ]);

    }

    public function paymentAction($id, Request $request){

        $em = $this->getDoctrine()->getManager();
        $reservation = $em->getRepository('NBMainBundle:Reservation')->find($id);


        return $this->render('NBMainBundle::payment.html.twig', [
            'reservation' => $reservation
        ]);

    }


    public function callbackAction(Request $request){

        $em = $this->getDoctrine()->getManager();
        $transaction = new Transaction();

        /************************************************************************************
        STEP 1 - CONFIGURATION : START
        Find your merchant UID, Public Key and secret code on the
        home page of your merchant dashboard
         *************************************************************************************/


        $merchant_uid = 'lywG2RnO5lZyWUczbiaEtO00Y1c2';            // Replace with your merchant_uid
        $merchant_public_key = 'q6Fs62Quar7BNIiNNlfmuwfx60y6hIcAjsjr9JhOFq1o'; // Replace by your merchant_public_key !!!
        $merchant_secret = 'sCJ4qhTseoh8DR8z';                       // Replace by your merchant_private_key !!!


        /*************************************************************************************
        STEP 1 - CONFIGURATION : END
         **************************************************************************************/

        /*************************************************************************************
        STEP 2 - CREATING AND GETTING THE POST REQUEST VARIABLES : START
        Create and initialize variables to be sent to confirm that
        the ongoing transaction is associated with the current merchant
         **************************************************************************************/

        $transaction_uid = '';//create an empty transaction_uid
        $transaction_token  = '';//create an empty transaction_token
        $transaction_provider_name  = ''; //create an empty transaction_provider_name
        $transaction_confirmation_code  = ''; //create an empty confirmation code
        $transaction_receiver_reference = "";

//extracting data from the post
        if($request->get('transaction_uid')){
            $transaction_uid = $request->get('transaction_uid'); //Get the transaction_uid posted by the payment box
        }

        if($request->get('transaction_token')){
            $transaction_token  = $request->get('transaction_token'); //Get the transaction_token posted by the payment box
        }

        if($request->get('transaction_provider_name')){
            $transaction_provider_name  = $request->get('transaction_provider_name'); //Get the transaction_provider_name posted by the payment box
        }

        if($request->get('transaction_confirmation_code')){
            $transaction_confirmation_code  = $request->get('transaction_confirmation_code'); //Get the transaction_confirmation_code posted by the payment box
        }

        if($request->get('transaction_receiver_reference')){
            $transaction_receiver_reference  = $request->get('transaction_receiver_reference'); //Get the transaction_confirmation_code posted by the payment box
        }



        echo $transaction_receiver_reference; exit;
    }

    public function webhookAction(Request $request){

    }

}