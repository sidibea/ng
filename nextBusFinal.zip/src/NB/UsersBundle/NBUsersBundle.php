<?php

namespace NB\UsersBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NBUsersBundle extends Bundle
{
}
